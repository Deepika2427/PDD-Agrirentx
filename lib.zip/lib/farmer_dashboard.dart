import 'package:flutter/material.dart';
import 'app_theme.dart';
import 'session.dart';
import 'api_service.dart';
import 'equipment_model.dart';
import 'equipment_search_screen.dart';
import 'equipment_details_screen.dart';
import 'booking_history_screen.dart';
import 'profile_screen.dart';
import 'notifications_screen.dart';

class FarmerDashboard extends StatefulWidget {
  const FarmerDashboard({super.key});

  @override
  State<FarmerDashboard> createState() => _FarmerDashboardState();
}

class _FarmerDashboardState extends State<FarmerDashboard> {
  int _index = 0;

  late final List<Widget> _tabs = const [
    _FarmerHomeTab(),
    EquipmentSearchScreen(),
    BookingHistoryScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _index, children: _tabs),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        backgroundColor: Colors.white,
        indicatorColor: AppColors.primaryLight.withOpacity(0.25),
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.home_outlined),
              selectedIcon: Icon(Icons.home),
              label: 'Home'),
          NavigationDestination(
              icon: Icon(Icons.search),
              selectedIcon: Icon(Icons.search),
              label: 'Search'),
          NavigationDestination(
              icon: Icon(Icons.receipt_long_outlined),
              selectedIcon: Icon(Icons.receipt_long),
              label: 'Bookings'),
          NavigationDestination(
              icon: Icon(Icons.person_outline),
              selectedIcon: Icon(Icons.person),
              label: 'Profile'),
        ],
      ),
    );
  }
}

class _FarmerHomeTab extends StatefulWidget {
  const _FarmerHomeTab();

  @override
  State<_FarmerHomeTab> createState() => _FarmerHomeTabState();
}

class _FarmerHomeTabState extends State<_FarmerHomeTab> {
  bool _loading = true;
  String? _error;
  List<Equipment> _recommended = [];
  List<Map> _recent = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final res = await ApiService.farmerDashboard(Session.userId!);
      _recommended = (res['recommended'] as List)
          .map((e) => Equipment.fromJson(e))
          .toList();
      _recent = (res['recent_bookings'] as List).cast<Map>();
    } catch (e) {
      _error = e.toString().replaceFirst('Exception: ', '');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Color _statusColor(String s) {
    switch (s) {
      case 'Approved':
        return AppColors.primary;
      case 'Pending':
        return AppColors.warning;
      case 'Cancelled':
      case 'Rejected':
        return AppColors.danger;
      default:
        return AppColors.textMuted;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AgriRentX'),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const NotificationsScreen()),
            ),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? _ErrorRetry(message: _error!, onRetry: _load)
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      Container(
                        padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(colors: [
                            AppColors.primary,
                            AppColors.primaryLight
                          ]),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Hello, ${Session.name ?? 'Farmer'} 👋',
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold)),
                            const SizedBox(height: 6),
                            const Text(
                                'Find and rent the equipment you need today.',
                                style: TextStyle(color: Colors.white70)),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),
                      _header(context, 'Recommended Equipment'),
                      const SizedBox(height: 12),
                      if (_recommended.isEmpty)
                        const Text('No equipment available yet.',
                            style: TextStyle(color: AppColors.textMuted))
                      else
                        SizedBox(
                          height: 190,
                          child: ListView.separated(
                            scrollDirection: Axis.horizontal,
                            itemCount: _recommended.length,
                            separatorBuilder: (_, __) =>
                                const SizedBox(width: 12),
                            itemBuilder: (_, i) =>
                                _RecommendCard(item: _recommended[i]),
                          ),
                        ),
                      const SizedBox(height: 24),
                      const _NearbySection(),
                      const SizedBox(height: 24),
                      _header(context, 'Recent Bookings'),
                      const SizedBox(height: 12),
                      if (_recent.isEmpty)
                        const Text('No bookings yet.',
                            style: TextStyle(color: AppColors.textMuted))
                      else
                        ..._recent.map((b) => Card(
                              child: ListTile(
                                leading: const CircleAvatar(
                                  backgroundColor: AppColors.background,
                                  child: Icon(Icons.agriculture,
                                      color: AppColors.primary),
                                ),
                                title: Text(b['equipment_name'] ?? '',
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis),
                                subtitle: Text(b['dates'] ?? ''),
                                trailing: Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: _statusColor(b['status'])
                                        .withOpacity(0.12),
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: Text(b['status'] ?? '',
                                      style: TextStyle(
                                          color: _statusColor(b['status']),
                                          fontWeight: FontWeight.w600)),
                                ),
                              ),
                            )),
                    ],
                  ),
                ),
    );
  }

  Widget _header(BuildContext context, String title) => Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title,
              style:
                  const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          GestureDetector(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const EquipmentSearchScreen()),
            ),
            child: const Text('See all',
                style: TextStyle(
                    color: AppColors.primary, fontWeight: FontWeight.w600)),
          ),
        ],
      );
}

class _NearbySection extends StatefulWidget {
  const _NearbySection();

  @override
  State<_NearbySection> createState() => _NearbySectionState();
}

class _NearbySectionState extends State<_NearbySection> {
  bool _loading = true;
  List<String> _cities = [];
  String? _city;
  List<Equipment> _items = [];

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      final loc = await ApiService.locations();
      _cities = (loc['cities'] as List).cast<String>();
      _city = _cities.contains(Session.city) ? Session.city : (_cities.isNotEmpty ? _cities.first : null);
    } catch (_) {}
    await _loadNearby();
  }

  Future<void> _loadNearby() async {
    setState(() => _loading = true);
    try {
      final list = await ApiService.nearbyEquipment(Session.userId!,
          city: _city, state: Session.state);
      _items = list.map((e) => Equipment.fromJson(e)).toList();
    } catch (_) {
      _items = [];
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Available Near You',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
            if (_cities.isNotEmpty)
              DropdownButton<String>(
                value: _city,
                underline: const SizedBox.shrink(),
                icon: const Icon(Icons.location_on_outlined,
                    color: AppColors.primary, size: 20),
                style: const TextStyle(
                    color: AppColors.primary, fontWeight: FontWeight.w600),
                items: _cities
                    .map((c) => DropdownMenuItem(
                          value: c,
                          child: Text(c,
                              style:
                                  const TextStyle(color: AppColors.primary)),
                        ))
                    .toList(),
                onChanged: (v) {
                  setState(() => _city = v);
                  _loadNearby();
                },
              ),
          ],
        ),
        const SizedBox(height: 12),
        if (_loading)
          const Padding(
            padding: EdgeInsets.all(20),
            child: Center(child: CircularProgressIndicator()),
          )
        else if (_items.isEmpty)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.border),
            ),
            child: const Text('No equipment available in this area right now.',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppColors.textMuted)),
          )
        else
          ..._items.map((e) => Card(
                margin: const EdgeInsets.only(bottom: 10),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: AppColors.background,
                    child: Icon(iconForCategory(e.category),
                        color: AppColors.primary),
                  ),
                  title: Text(e.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: Text(e.shortLocation),
                  trailing: Text('₹${e.pricePerDay.toStringAsFixed(0)}/day',
                      style: const TextStyle(
                          color: AppColors.primary,
                          fontWeight: FontWeight.bold)),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => EquipmentDetailsScreen(equipment: e)),
                  ),
                ),
              )),
      ],
    );
  }
}

class _RecommendCard extends StatelessWidget {
  final Equipment item;
  const _RecommendCard({required this.item});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) => EquipmentDetailsScreen(equipment: item)),
      ),
      child: Container(
        width: 200,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 70,
              width: double.infinity,
              decoration: BoxDecoration(
                color: AppColors.background,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(iconForCategory(item.category),
                  size: 40, color: AppColors.primary),
            ),
            const SizedBox(height: 10),
            Text(item.name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Row(
              children: [
                const Icon(Icons.star, size: 15, color: AppColors.warning),
                Text(' ${item.rating}',
                    style: const TextStyle(color: AppColors.textMuted)),
              ],
            ),
            const Spacer(),
            Text('₹${item.pricePerDay.toStringAsFixed(0)}/day',
                style: const TextStyle(
                    color: AppColors.primary, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}

class _ErrorRetry extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  const _ErrorRetry({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.cloud_off, size: 48, color: AppColors.textMuted),
            const SizedBox(height: 12),
            Text(message, textAlign: TextAlign.center),
            const SizedBox(height: 16),
            ElevatedButton(onPressed: onRetry, child: const Text('Retry')),
          ],
        ),
      ),
    );
  }
}
