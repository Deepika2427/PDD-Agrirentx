class Url {
  static String Urls = 'https://web-production-8b61c.up.railway.app';
}
//${Url.Urls}
