// Static holder for the logged-in user's state, populated after login.
class Session {
  static int? userId;
  static String? name;
  static String? email;
  static String? role; // 'farmer' or 'owner'
  static String? area;
  static String? city;
  static String? state;
  static double walletBalance = 0;

  static void setFromUser(Map user) {
    userId = user['id'];
    name = user['name'];
    email = user['email'];
    role = user['role'];
    area = user['area'];
    city = user['city'];
    state = user['state'];
    walletBalance = (user['wallet_balance'] ?? 0).toDouble();
  }

  static void clear() {
    userId = null;
    name = null;
    email = null;
    role = null;
    area = null;
    city = null;
    state = null;
    walletBalance = 0;
  }
}
