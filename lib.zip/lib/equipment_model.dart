import 'package:flutter/material.dart';

// Maps an equipment category to a matching Material icon.
IconData iconForCategory(String category) {
  switch (category) {
    case 'Tractor':
      return Icons.agriculture;
    case 'Harvester':
      return Icons.grass;
    case 'Plough':
      return Icons.yard;
    case 'Sprayer':
      return Icons.water_drop;
    case 'Vehicle':
      return Icons.local_shipping;
    case 'Tools':
      return Icons.handyman;
    default:
      return Icons.category;
  }
}

class Equipment {
  final int id;
  final int ownerId;
  final String name;
  final String category;
  final String area;
  final String city;
  final String state;
  final double pricePerDay;
  final String ownerName;
  final String ownerPhone;
  final double rating;
  final int reviewCount;
  final bool available;
  final String description;
  final String specs;

  const Equipment({
    required this.id,
    required this.ownerId,
    required this.name,
    required this.category,
    required this.area,
    required this.city,
    required this.state,
    required this.pricePerDay,
    required this.ownerName,
    required this.ownerPhone,
    required this.rating,
    required this.reviewCount,
    required this.available,
    required this.description,
    required this.specs,
  });

  factory Equipment.fromJson(Map j) => Equipment(
        id: j['id'],
        ownerId: j['owner_id'] ?? 0,
        name: j['name'] ?? '',
        category: j['category'] ?? '',
        area: j['area'] ?? '',
        city: j['city'] ?? '',
        state: j['state'] ?? '',
        pricePerDay: (j['price_per_day'] ?? 0).toDouble(),
        ownerName: j['owner_name'] ?? '',
        ownerPhone: j['owner_phone'] ?? '',
        rating: (j['rating'] ?? 0).toDouble(),
        reviewCount: j['review_count'] ?? 0,
        available: j['available'] == true || j['available'] == 1,
        description: j['description'] ?? '',
        specs: j['specs'] ?? '',
      );

  String get location => '$area, $city, $state';
  String get shortLocation => '$area, $city';
}

const List<String> equipmentCategories = [
  'All',
  'Tractor',
  'Harvester',
  'Plough',
  'Sprayer',
  'Vehicle',
  'Tools',
];

// Fallback state list for the dropdowns.
const List<String> indianStates = [
  'Tamil Nadu',
  'Kerala',
  'Karnataka',
  'Andhra Pradesh',
  'Telangana',
  'Maharashtra',
];
