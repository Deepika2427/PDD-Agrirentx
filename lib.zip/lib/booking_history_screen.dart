import 'package:flutter/material.dart';
import 'app_theme.dart';
import 'session.dart';
import 'api_service.dart';
import 'invoice_screen.dart';

class BookingHistoryScreen extends StatefulWidget {
  const BookingHistoryScreen({super.key});

  @override
  State<BookingHistoryScreen> createState() => _BookingHistoryScreenState();
}

class _BookingHistoryScreenState extends State<BookingHistoryScreen> {
  bool _loading = true;
  List<Map> _all = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final list = await ApiService.farmerBookings(Session.userId!);
      _all = list.cast<Map>();
    } catch (_) {
      _all = [];
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  List<Map> _filter(String tab) {
    if (tab == 'current') {
      return _all
          .where((b) => b['status'] == 'Pending' || b['status'] == 'Approved')
          .toList();
    }
    if (tab == 'completed') {
      return _all.where((b) => b['status'] == 'Completed').toList();
    }
    return _all
        .where((b) => b['status'] == 'Cancelled' || b['status'] == 'Rejected')
        .toList();
  }

  Color _statusColor(String s) {
    switch (s) {
      case 'Approved':
        return AppColors.primary;
      case 'Pending':
        return AppColors.warning;
      case 'Cancelled':
      case 'Rejected':
        return AppColors.danger;
      default:
        return AppColors.textMuted;
    }
  }

  Future<void> _cancel(Map b) async {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Cancel Booking'),
        content: const Text('Are you sure you want to cancel this booking?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('No')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.danger,
                minimumSize: const Size(90, 42)),
            onPressed: () async {
              Navigator.pop(context);
              try {
                await ApiService.updateBookingStatus(b['id'], 'cancelled');
                await _load();
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Booking cancelled')),
                  );
                }
              } catch (e) {
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: Text(
                          e.toString().replaceFirst('Exception: ', ''))));
                }
              }
            },
            child: const Text('Yes, Cancel'),
          ),
        ],
      ),
    );
  }

  void _rate(Map b) {
    double rating = 4;
    final reviewCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setDialog) => AlertDialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Text('Rate & Review'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(5, (i) {
                  return IconButton(
                    padding: EdgeInsets.zero,
                    icon: Icon(i < rating ? Icons.star : Icons.star_border,
                        color: AppColors.warning),
                    onPressed: () => setDialog(() => rating = i + 1.0),
                  );
                }),
              ),
              TextField(
                controller: reviewCtrl,
                maxLines: 2,
                decoration:
                    const InputDecoration(hintText: 'Write a review...'),
              ),
            ],
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Cancel')),
            ElevatedButton(
              style:
                  ElevatedButton.styleFrom(minimumSize: const Size(90, 42)),
              onPressed: () async {
                Navigator.pop(context);
                try {
                  await ApiService.addReview({
                    'equipment_id': b['equipment_id'],
                    'booking_id': b['id'],
                    'farmer_id': Session.userId,
                    'rating': rating,
                    'comment': reviewCtrl.text.trim(),
                  });
                  await _load();
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                          content: Text('Thank you for your review!')),
                    );
                  }
                } catch (e) {
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text(
                            e.toString().replaceFirst('Exception: ', ''))));
                  }
                }
              },
              child: const Text('Submit'),
            ),
          ],
        ),
      ),
    );
  }

  void _invoice(Map b) {
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (_) => InvoiceScreen(bookingId: b['id'])),
    );
  }

  Widget _list(List<Map> items) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (items.isEmpty) {
      return const Center(child: Text('No bookings here yet'));
    }
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: items.length,
        itemBuilder: (_, i) {
          final b = items[i];
          final status = b['status'] as String;
          final color = _statusColor(status);
          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const CircleAvatar(
                        backgroundColor: AppColors.background,
                        child:
                            Icon(Icons.agriculture, color: AppColors.primary),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(b['equipment_name'] ?? '',
                            style: const TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 15)),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: color.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(status,
                            style: TextStyle(
                                color: color, fontWeight: FontWeight.w600)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      const Icon(Icons.calendar_today_outlined,
                          size: 15, color: AppColors.textMuted),
                      Text('  ${b['dates']}',
                          style:
                              const TextStyle(color: AppColors.textMuted)),
                      const Spacer(),
                      Text('₹${b['amount']}',
                          style: const TextStyle(
                              color: AppColors.primary,
                              fontWeight: FontWeight.bold)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 10,
                    runSpacing: 4,
                    children: [
                      OutlinedButton(
                        onPressed: () => _invoice(b),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: AppColors.primary,
                          side: const BorderSide(color: AppColors.primary),
                        ),
                        child: const Text('View Invoice'),
                      ),
                      if (status == 'Pending')
                        TextButton(
                          onPressed: () => _cancel(b),
                          style: TextButton.styleFrom(
                              foregroundColor: AppColors.danger),
                          child: const Text('Cancel'),
                        ),
                      if (status == 'Completed')
                        (b['reviewed'] == true)
                            ? const Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.check_circle,
                                      size: 18, color: AppColors.primary),
                                  SizedBox(width: 4),
                                  Text('Reviewed',
                                      style: TextStyle(
                                          color: AppColors.primary,
                                          fontWeight: FontWeight.w600)),
                                ],
                              )
                            : TextButton(
                                onPressed: () => _rate(b),
                                child: const Text('Rate & Review'),
                              ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('My Bookings'),
          bottom: const TabBar(
            indicatorColor: Colors.white,
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            tabs: [
              Tab(text: 'Current'),
              Tab(text: 'Completed'),
              Tab(text: 'Cancelled'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _list(_filter('current')),
            _list(_filter('completed')),
            _list(_filter('cancelled')),
          ],
        ),
      ),
    );
  }
}
