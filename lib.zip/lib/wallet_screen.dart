import 'package:flutter/material.dart';
import 'app_theme.dart';
import 'session.dart';
import 'api_service.dart';

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});

  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  bool _loading = true;
  double _balance = 0;
  List _txns = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final res = await ApiService.getWallet(Session.userId!);
      _balance = (res['balance'] ?? 0).toDouble();
      _txns = res['transactions'] ?? [];
      Session.walletBalance = _balance;
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  void _recharge() {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Recharge Wallet'),
        content: TextField(
          controller: ctrl,
          keyboardType: TextInputType.number,
          decoration:
              const InputDecoration(labelText: 'Amount', prefixText: '₹ '),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(minimumSize: const Size(90, 42)),
            onPressed: () async {
              final amt = double.tryParse(ctrl.text) ?? 0;
              Navigator.pop(context);
              if (amt <= 0) return;
              try {
                await ApiService.rechargeWallet(Session.userId!, amt);
                await _load();
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Wallet recharged')),
                  );
                }
              } catch (e) {
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: Text(
                          e.toString().replaceFirst('Exception: ', ''))));
                }
              }
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Wallet')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Container(
                    padding: const EdgeInsets.all(22),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [
                        AppColors.primary,
                        AppColors.primaryLight
                      ]),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Wallet Balance',
                            style: TextStyle(color: Colors.white70)),
                        const SizedBox(height: 6),
                        Text('₹${_balance.toStringAsFixed(0)}',
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 30,
                                fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton.icon(
                    onPressed: _recharge,
                    icon: const Icon(Icons.add),
                    label: const Text('Recharge Wallet'),
                  ),
                  const SizedBox(height: 20),
                  const Text('Transaction History',
                      style: TextStyle(
                          fontSize: 16, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  if (_txns.isEmpty)
                    const Text('No transactions yet.',
                        style: TextStyle(color: AppColors.textMuted))
                  else
                    ..._txns.map((t) {
                      final credit = t['type'] == 'credit';
                      return Card(
                        margin: const EdgeInsets.only(bottom: 10),
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor: AppColors.background,
                            child: Icon(
                                credit
                                    ? Icons.south_west
                                    : Icons.north_east,
                                color: credit
                                    ? AppColors.primary
                                    : AppColors.danger),
                          ),
                          title: Text(t['title'] ?? '',
                              style: const TextStyle(
                                  fontWeight: FontWeight.w600)),
                          subtitle: Text(t['created_at'] ?? ''),
                          trailing: Text(
                            '${credit ? '+' : '-'}₹${t['amount']}',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: credit
                                    ? AppColors.primary
                                    : AppColors.danger),
                          ),
                        ),
                      );
                    }),
                ],
              ),
            ),
    );
  }
}
