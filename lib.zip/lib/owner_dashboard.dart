import 'package:flutter/material.dart';
import 'app_theme.dart';
import 'session.dart';
import 'api_service.dart';
import 'add_equipment_screen.dart';
import 'owner_bookings_screen.dart';
import 'earnings_screen.dart';
import 'profile_screen.dart';
import 'notifications_screen.dart';
import 'booking_request_detail_screen.dart';

class OwnerDashboard extends StatefulWidget {
  const OwnerDashboard({super.key});

  @override
  State<OwnerDashboard> createState() => _OwnerDashboardState();
}

class _OwnerDashboardState extends State<OwnerDashboard> {
  int _index = 0;

  late final List<Widget> _tabs = const [
    _OwnerHomeTab(),
    OwnerBookingsScreen(),
    EarningsScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _index, children: _tabs),
      floatingActionButton: _index == 0
          ? FloatingActionButton.extended(
              backgroundColor: AppColors.primary,
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AddEquipmentScreen()),
              ),
              icon: const Icon(Icons.add, color: Colors.white),
              label: const Text('Add Equipment',
                  style: TextStyle(color: Colors.white)),
            )
          : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        backgroundColor: Colors.white,
        indicatorColor: AppColors.primaryLight.withOpacity(0.25),
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.dashboard_outlined),
              selectedIcon: Icon(Icons.dashboard),
              label: 'Dashboard'),
          NavigationDestination(
              icon: Icon(Icons.list_alt_outlined),
              selectedIcon: Icon(Icons.list_alt),
              label: 'Bookings'),
          NavigationDestination(
              icon: Icon(Icons.account_balance_wallet_outlined),
              selectedIcon: Icon(Icons.account_balance_wallet),
              label: 'Earnings'),
          NavigationDestination(
              icon: Icon(Icons.person_outline),
              selectedIcon: Icon(Icons.person),
              label: 'Profile'),
        ],
      ),
    );
  }
}

class _OwnerHomeTab extends StatefulWidget {
  const _OwnerHomeTab();

  @override
  State<_OwnerHomeTab> createState() => _OwnerHomeTabState();
}

class _OwnerHomeTabState extends State<_OwnerHomeTab> {
  bool _loading = true;
  Map _data = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      _data = await ApiService.ownerDashboard(Session.userId!);
    } catch (_) {
      _data = {};
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final requests = (_data['recent_requests'] as List?)?.cast<Map>() ?? [];
    final revenue = (_data['monthly_revenue'] as Map?) ?? {};
    return Scaffold(
      appBar: AppBar(
        title: const Text('Owner Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const NotificationsScreen()),
            ),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Text('Welcome, ${_data['name'] ?? Session.name ?? 'Owner'}',
                      style: const TextStyle(
                          fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 16),
                  GridView.count(
                    crossAxisCount: 2,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                    childAspectRatio: 1.35,
                    children: [
                      _StatCard(
                          label: 'Equipment Listed',
                          value: '${_data['equipment_listed'] ?? 0}',
                          icon: Icons.inventory_2_outlined),
                      _StatCard(
                          label: 'Active Bookings',
                          value: '${_data['active_bookings'] ?? 0}',
                          icon: Icons.event_available_outlined),
                      _StatCard(
                          label: 'Total Earnings',
                          value: '₹${_data['total_earnings'] ?? 0}',
                          icon: Icons.payments_outlined),
                      _StatCard(
                          label: 'This Month',
                          value: '₹${_data['month_earnings'] ?? 0}',
                          icon: Icons.trending_up),
                    ],
                  ),
                  const SizedBox(height: 20),
                  const Text('Monthly Revenue',
                      style: TextStyle(
                          fontSize: 16, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  _RevenueChart(data: revenue),
                  const SizedBox(height: 20),
                  const Text('Recent Booking Requests',
                      style: TextStyle(
                          fontSize: 16, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  if (requests.isEmpty)
                    const Text('No booking requests yet.',
                        style: TextStyle(color: AppColors.textMuted))
                  else
                    ...requests.map((b) => Card(
                          margin: const EdgeInsets.only(bottom: 10),
                          child: ListTile(
                            leading: const CircleAvatar(
                              backgroundColor: AppColors.background,
                              child:
                                  Icon(Icons.person, color: AppColors.primary),
                            ),
                            title: Text(b['equipment_name'] ?? '',
                                style: const TextStyle(
                                    fontWeight: FontWeight.w600)),
                            subtitle:
                                Text('${b['farmer_name']} • ${b['dates']}'),
                            trailing: const Icon(Icons.chevron_right),
                            onTap: () async {
                              await Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) =>
                                      BookingRequestDetailScreen(bookingId: b['id']),
                                ),
                              );
                              _load();
                            },
                          ),
                        )),
                ],
              ),
            ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  const _StatCard(
      {required this.label, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: AppColors.primary, size: 26),
          const SizedBox(height: 8),
          Text(value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style:
                  const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          Text(label,
              style:
                  const TextStyle(color: AppColors.textMuted, fontSize: 12)),
        ],
      ),
    );
  }
}

class _RevenueChart extends StatelessWidget {
  final Map data;
  const _RevenueChart({required this.data});

  @override
  Widget build(BuildContext context) {
    final entries = data.entries.toList();
    if (entries.isEmpty) {
      return Container(
        height: 120,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.border),
        ),
        child: const Text('No revenue data yet',
            style: TextStyle(color: AppColors.textMuted)),
      );
    }
    final maxVal = entries
        .map((e) => (e.value as num).toDouble())
        .reduce((a, b) => a > b ? a : b);
    return Container(
      height: 196,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: entries.map((e) {
          final v = (e.value as num).toDouble();
          final h = maxVal == 0 ? 0.0 : (v / maxVal) * 104;
          return Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Text('${(v / 1000).toStringAsFixed(0)}k',
                  style: const TextStyle(
                      fontSize: 11, color: AppColors.textMuted)),
              const SizedBox(height: 4),
              Container(
                width: 22,
                height: h,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                    colors: [AppColors.primary, AppColors.primaryLight],
                  ),
                  borderRadius: BorderRadius.circular(6),
                ),
              ),
              const SizedBox(height: 6),
              Text('${e.key}',
                  style: const TextStyle(
                      fontSize: 11, color: AppColors.textMuted)),
            ],
          );
        }).toList(),
      ),
    );
  }
}
