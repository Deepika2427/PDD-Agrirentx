import 'package:flutter/material.dart';
import 'app_theme.dart';
import 'splash_screen.dart';

void main() {
  runApp(const AgriRentXApp());
}

class AgriRentXApp extends StatelessWidget {
  const AgriRentXApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AgriRentX',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.theme,
      home: const SplashScreen(),
    );
  }
}
