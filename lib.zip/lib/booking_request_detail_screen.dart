import 'package:flutter/material.dart';
import 'app_theme.dart';
import 'api_service.dart';
import 'chat_screen.dart';

class BookingRequestDetailScreen extends StatefulWidget {
  final int bookingId;
  const BookingRequestDetailScreen({super.key, required this.bookingId});

  @override
  State<BookingRequestDetailScreen> createState() =>
      _BookingRequestDetailScreenState();
}

class _BookingRequestDetailScreenState
    extends State<BookingRequestDetailScreen> {
  bool _loading = true;
  Map _b = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      _b = await ApiService.getBooking(widget.bookingId);
    } catch (_) {
      _b = {};
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Color _statusColor(String s) {
    switch (s) {
      case 'Approved':
        return AppColors.primary;
      case 'Rejected':
        return AppColors.danger;
      case 'Completed':
        return AppColors.textMuted;
      default:
        return AppColors.warning;
    }
  }

  Future<void> _update(String s) async {
    try {
      await ApiService.updateBookingStatus(widget.bookingId, s);
      await _load();
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Booking $s')));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(e.toString().replaceFirst('Exception: ', ''))));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Scaffold(
        appBar: AppBar(title: const Text('Booking Details')),
        body: const Center(child: CircularProgressIndicator()),
      );
    }
    final status = (_b['status'] ?? 'Pending') as String;
    final color = _statusColor(status);
    return Scaffold(
      appBar: AppBar(title: const Text('Booking Details')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Center(
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(status,
                  style: TextStyle(
                      color: color,
                      fontWeight: FontWeight.bold,
                      fontSize: 15)),
            ),
          ),
          const SizedBox(height: 20),
          _card('Equipment', [
            _row(Icons.agriculture, 'Equipment', _b['equipment_name'] ?? ''),
            _row(Icons.calendar_today_outlined, 'Rental Period',
                _b['dates'] ?? ''),
            _row(Icons.payments_outlined, 'Total Amount',
                '₹${_b['amount'] ?? 0}'),
          ]),
          const SizedBox(height: 16),
          _card('Farmer Details', [
            _row(Icons.person_outline, 'Name', _b['farmer_name'] ?? ''),
            _row(Icons.phone_outlined, 'Phone', _b['farmer_phone'] ?? '-'),
          ]),
          const SizedBox(height: 16),
          OutlinedButton.icon(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ChatScreen(
                    otherUserId: _b['farmer_id'],
                    otherUserName: _b['farmer_name'] ?? 'Farmer'),
              ),
            ),
            style: OutlinedButton.styleFrom(
              foregroundColor: AppColors.primary,
              minimumSize: const Size.fromHeight(46),
              side: const BorderSide(color: AppColors.primary),
            ),
            icon: const Icon(Icons.chat_bubble_outline),
            label: Text('Message ${_b['farmer_name'] ?? 'Farmer'}'),
          ),
        ],
      ),
      bottomNavigationBar: status == 'Pending'
          ? Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => _update('approved'),
                      child: const Text('Approve'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => _update('rejected'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: AppColors.danger,
                        minimumSize: const Size.fromHeight(50),
                        side: const BorderSide(color: AppColors.danger),
                      ),
                      child: const Text('Reject'),
                    ),
                  ),
                ],
              ),
            )
          : (status == 'Approved'
              ? Padding(
                  padding: const EdgeInsets.all(16),
                  child: ElevatedButton(
                    onPressed: () => _update('completed'),
                    child: const Text('Mark as Completed'),
                  ),
                )
              : null),
    );
  }

  Widget _card(String title, List<Widget> rows) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style: const TextStyle(
                    fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            ...rows,
          ],
        ),
      );

  Widget _row(IconData icon, String label, String value) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 18, color: AppColors.primary),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label,
                      style: const TextStyle(
                          color: AppColors.textMuted, fontSize: 12)),
                  const SizedBox(height: 2),
                  Text(value,
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                ],
              ),
            ),
          ],
        ),
      );
}
