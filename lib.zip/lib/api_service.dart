import 'dart:convert';
import 'package:http/http.dart' as http;
import 'url.dart';

/// Central handler for every backend call. All screens go through this class.
class ApiService {
  static const Duration _timeout = Duration(seconds: 25);
  static const Map<String, String> _headers = {
    'Content-Type': 'application/json',
  };

  static Uri _uri(String path, [Map<String, dynamic>? query]) {
    final clean = <String, String>{};
    if (query != null) {
      query.forEach((k, v) {
        if (v != null) clean[k] = v.toString();
      });
    }
    return Uri.parse('${Url.Urls}$path')
        .replace(queryParameters: clean.isEmpty ? null : clean);
  }

  static dynamic _decode(http.Response r) {
    final dynamic body = r.body.isEmpty ? {} : jsonDecode(r.body);
    if (r.statusCode >= 200 && r.statusCode < 300) return body;
    final msg = (body is Map && body['error'] != null)
        ? body['error'].toString()
        : 'Something went wrong (${r.statusCode})';
    throw Exception(msg);
  }

  static Future<dynamic> _get(String path, [Map<String, dynamic>? query]) async {
    final r = await http.get(_uri(path, query)).timeout(_timeout);
    return _decode(r);
  }

  static Future<dynamic> _post(String path, Map body) async {
    final r = await http
        .post(_uri(path), headers: _headers, body: jsonEncode(body))
        .timeout(_timeout);
    return _decode(r);
  }

  static Future<dynamic> _put(String path, [Map? body]) async {
    final r = await http
        .put(_uri(path), headers: _headers, body: jsonEncode(body ?? {}))
        .timeout(_timeout);
    return _decode(r);
  }

  static Future<dynamic> _delete(String path) async {
    final r = await http.delete(_uri(path)).timeout(_timeout);
    return _decode(r);
  }

  // ── Auth ──────────────────────────────────────────────
  static Future<Map> signup(Map data) async => await _post('/signup', data);

  static Future<Map> login(String email, String password) async =>
      await _post('/login', {'email': email, 'password': password});

  static Future<void> logout(String email) async =>
      await _post('/logout', {'email': email});

  // ── Profile ───────────────────────────────────────────
  static Future<Map> getProfile(int id) async => await _get('/profile/$id');

  static Future<void> updateProfile(int id, Map data) async =>
      await _put('/profile/$id', data);

  static Future<void> changePassword(int id, String oldP, String newP) async =>
      await _put('/change_password/$id',
          {'old_password': oldP, 'new_password': newP});

  // ── Equipment ─────────────────────────────────────────
  static Future<List> listEquipment({
    String? q,
    String? category,
    double? minPrice,
    double? maxPrice,
    bool? available,
    String? city,
    String? state,
  }) async {
    return await _get('/equipment', {
      'q': q,
      'category': category,
      'min_price': minPrice,
      'max_price': maxPrice,
      'available': available,
      'city': city,
      'state': state,
    });
  }

  static Future<Map> getEquipment(int id) async =>
      await _get('/equipment/$id');

  static Future<List> ownerEquipment(int ownerId) async =>
      await _get('/equipment/owner/$ownerId');

  static Future<List> nearbyEquipment(int userId,
          {String? city, String? state}) async =>
      await _get('/equipment/nearby/$userId', {'city': city, 'state': state});

  static Future<Map> addEquipment(Map data) async =>
      await _post('/equipment', data);

  static Future<void> updateEquipment(int id, Map data) async =>
      await _put('/equipment/$id', data);

  static Future<void> deleteEquipment(int id) async =>
      await _delete('/equipment/$id');

  static Future<Map> locations() async => await _get('/locations');

  // ── Bookings ──────────────────────────────────────────
  static Future<Map> createBooking(Map data) async =>
      await _post('/bookings', data);

  static Future<List> farmerBookings(int farmerId, {String? status}) async =>
      await _get('/bookings/farmer/$farmerId', {'status': status});

  static Future<List> ownerBookings(int ownerId, {String? status}) async =>
      await _get('/bookings/owner/$ownerId', {'status': status});

  static Future<Map> getBooking(int id) async => await _get('/bookings/$id');

  static Future<void> updateBookingStatus(int id, String status) async =>
      await _put('/bookings/$id/status', {'status': status});

  static Future<Map> bookingInvoice(int id) async =>
      await _get('/bookings/$id/invoice');

  // ── Payments ──────────────────────────────────────────
  static Future<Map> makePayment(Map data) async =>
      await _post('/payments', data);

  // ── Reviews ───────────────────────────────────────────
  static Future<Map> addReview(Map data) async =>
      await _post('/reviews', data);

  static Future<List> getReviews(int equipmentId) async =>
      await _get('/reviews/$equipmentId');

  // ── Chat / Messages ───────────────────────────────────
  static Future<Map> sendMessage(int senderId, int receiverId, String text) async =>
      await _post('/messages',
          {'sender_id': senderId, 'receiver_id': receiverId, 'text': text});

  static Future<List> getConversation(int userId, int otherId) async =>
      await _get('/messages/$userId/$otherId');

  static Future<List> conversations(int userId) async =>
      await _get('/conversations/$userId');

  // ── Notifications ─────────────────────────────────────
  static Future<List> notifications(int userId) async =>
      await _get('/notifications/$userId');

  static Future<void> markNotificationRead(int id) async =>
      await _put('/notifications/$id/read');

  // ── Wallet ────────────────────────────────────────────
  static Future<Map> getWallet(int userId) async =>
      await _get('/wallet/$userId');

  static Future<Map> rechargeWallet(int userId, double amount) async =>
      await _post('/wallet/$userId/recharge', {'amount': amount});

  static Future<Map> withdrawWallet(int userId, double amount) async =>
      await _post('/wallet/$userId/withdraw', {'amount': amount});

  // ── Dashboards ────────────────────────────────────────
  static Future<Map> farmerDashboard(int userId) async =>
      await _get('/farmer/dashboard/$userId');

  static Future<Map> ownerDashboard(int ownerId) async =>
      await _get('/owner/dashboard/$ownerId');

  static Future<Map> ownerEarnings(int ownerId) async =>
      await _get('/owner/earnings/$ownerId');
}
