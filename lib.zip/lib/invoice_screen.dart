import 'package:flutter/material.dart';
import 'app_theme.dart';
import 'api_service.dart';

class InvoiceScreen extends StatefulWidget {
  final int bookingId;
  const InvoiceScreen({super.key, required this.bookingId});

  @override
  State<InvoiceScreen> createState() => _InvoiceScreenState();
}

class _InvoiceScreenState extends State<InvoiceScreen> {
  Map? _data;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      _data = await ApiService.bookingInvoice(widget.bookingId);
    } catch (_) {
      _data = null;
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Invoice')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _data == null
              ? const Center(child: Text('Could not load invoice'))
              : Padding(
                  padding: const EdgeInsets.all(20),
                  child: Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(
                          children: [
                            const CircleAvatar(
                              backgroundColor: AppColors.primary,
                              child: Icon(Icons.agriculture,
                                  color: Colors.white),
                            ),
                            const SizedBox(width: 10),
                            const Text('AgriRentX',
                                style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold)),
                            const Spacer(),
                            Text(_data!['invoice_no'] ?? 'INVOICE',
                                style: const TextStyle(
                                    color: AppColors.textMuted,
                                    fontWeight: FontWeight.bold)),
                          ],
                        ),
                        const Divider(height: 30),
                        _row('Equipment', _data!['equipment_name'] ?? ''),
                        const SizedBox(height: 12),
                        _row('Rental Period', _data!['dates'] ?? ''),
                        const SizedBox(height: 12),
                        _row('Days', '${_data!['days'] ?? ''}'),
                        const SizedBox(height: 12),
                        _row('Status', _data!['status'] ?? ''),
                        const Divider(height: 30),
                        _row('Total Amount', '₹${_data!['amount'] ?? 0}',
                            bold: true),
                        const SizedBox(height: 30),
                        SizedBox(
                          width: double.infinity,
                          child: OutlinedButton.icon(
                            onPressed: () {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                    content: Text('Invoice downloaded')),
                              );
                            },
                            style: OutlinedButton.styleFrom(
                              foregroundColor: AppColors.primary,
                              minimumSize: const Size.fromHeight(46),
                              side:
                                  const BorderSide(color: AppColors.primary),
                            ),
                            icon: const Icon(Icons.download),
                            label: const Text('Download Invoice'),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
    );
  }

  Widget _row(String label, String value, {bool bold = false}) => Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: AppColors.textMuted)),
          Flexible(
            child: Text(value,
                textAlign: TextAlign.right,
                style: TextStyle(
                  fontSize: bold ? 18 : 14,
                  fontWeight: bold ? FontWeight.bold : FontWeight.w600,
                  color: bold ? AppColors.primary : AppColors.textDark,
                )),
          ),
        ],
      );
}
