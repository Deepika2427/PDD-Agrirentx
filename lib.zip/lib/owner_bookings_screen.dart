import 'package:flutter/material.dart';
import 'app_theme.dart';
import 'session.dart';
import 'api_service.dart';
import 'booking_request_detail_screen.dart';

class OwnerBookingsScreen extends StatefulWidget {
  const OwnerBookingsScreen({super.key});

  @override
  State<OwnerBookingsScreen> createState() => _OwnerBookingsScreenState();
}

class _OwnerBookingsScreenState extends State<OwnerBookingsScreen> {
  bool _loading = true;
  List<Map> _bookings = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final list = await ApiService.ownerBookings(Session.userId!);
      _bookings = list.cast<Map>();
    } catch (_) {
      _bookings = [];
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _update(Map b, String status) async {
    try {
      await ApiService.updateBookingStatus(b['id'], status);
      await _load();
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Booking $status')));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(e.toString().replaceFirst('Exception: ', ''))));
      }
    }
  }

  Color _statusColor(String s) {
    switch (s) {
      case 'Approved':
        return AppColors.primary;
      case 'Rejected':
        return AppColors.danger;
      case 'Completed':
        return AppColors.textMuted;
      default:
        return AppColors.warning;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Booking Requests')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _bookings.isEmpty
              ? const Center(child: Text('No booking requests yet'))
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: _bookings.length,
                    itemBuilder: (_, i) {
                      final b = _bookings[i];
                      final status = b['status'] as String;
                      final color = _statusColor(status);
                      return Card(
                        margin: const EdgeInsets.only(bottom: 12),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(14),
                          onTap: () async {
                            await Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => BookingRequestDetailScreen(
                                    bookingId: b['id']),
                              ),
                            );
                            _load();
                          },
                          child: Padding(
                            padding: const EdgeInsets.all(14),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                      child: Text(b['equipment_name'] ?? '',
                                          style: const TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 15)),
                                    ),
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 10, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: color.withOpacity(0.12),
                                        borderRadius:
                                            BorderRadius.circular(20),
                                      ),
                                      child: Text(status,
                                          style: TextStyle(
                                              color: color,
                                              fontWeight: FontWeight.w600)),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 10),
                                Row(
                                  children: [
                                    const Icon(Icons.person_outline,
                                        size: 15, color: AppColors.textMuted),
                                    Text('  ${b['farmer_name']}',
                                        style: const TextStyle(
                                            color: AppColors.textMuted)),
                                    const Spacer(),
                                    const Icon(Icons.calendar_today_outlined,
                                        size: 15, color: AppColors.textMuted),
                                    Text('  ${b['dates']}',
                                        style: const TextStyle(
                                            color: AppColors.textMuted)),
                                  ],
                                ),
                                const SizedBox(height: 8),
                                Text('Amount: ₹${b['amount']}',
                                    style: const TextStyle(
                                        color: AppColors.primary,
                                        fontWeight: FontWeight.bold)),
                                const SizedBox(height: 12),
                                if (status == 'Pending')
                                  Row(
                                    children: [
                                      Expanded(
                                        child: ElevatedButton(
                                          onPressed: () =>
                                              _update(b, 'approved'),
                                          style: ElevatedButton.styleFrom(
                                              minimumSize:
                                                  const Size.fromHeight(42)),
                                          child: const Text('Approve'),
                                        ),
                                      ),
                                      const SizedBox(width: 10),
                                      Expanded(
                                        child: OutlinedButton(
                                          onPressed: () =>
                                              _update(b, 'rejected'),
                                          style: OutlinedButton.styleFrom(
                                            foregroundColor: AppColors.danger,
                                            minimumSize:
                                                const Size.fromHeight(42),
                                            side: const BorderSide(
                                                color: AppColors.danger),
                                          ),
                                          child: const Text('Reject'),
                                        ),
                                      ),
                                    ],
                                  )
                                else if (status == 'Approved')
                                  OutlinedButton(
                                    onPressed: () => _update(b, 'completed'),
                                    style: OutlinedButton.styleFrom(
                                      foregroundColor: AppColors.primary,
                                      minimumSize: const Size.fromHeight(42),
                                      side: const BorderSide(
                                          color: AppColors.primary),
                                    ),
                                    child: const Text('Mark as Completed'),
                                  ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
    );
  }
}
