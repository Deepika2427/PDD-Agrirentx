import 'package:flutter/material.dart';
import 'app_theme.dart';
import 'session.dart';
import 'api_service.dart';
import 'login_screen.dart';
import 'edit_profile_screen.dart';
import 'change_password_screen.dart';
import 'wallet_screen.dart';
import 'help_center_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  void _about() {
    showAboutDialog(
      context: context,
      applicationName: 'AgriRentX',
      applicationVersion: '1.0.0',
      applicationIcon: const CircleAvatar(
        backgroundColor: AppColors.primary,
        child: Icon(Icons.agriculture, color: Colors.white),
      ),
      children: const [
        Text(
            'AgriRentX is an agricultural equipment rental platform where farmers can rent farm machinery, vehicles and tools from equipment owners.'),
      ],
    );
  }

  void _logout() async {
    try {
      if (Session.email != null) await ApiService.logout(Session.email!);
    } catch (_) {}
    Session.clear();
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const SizedBox(height: 10),
          const CircleAvatar(
            radius: 44,
            backgroundColor: AppColors.primary,
            child: Icon(Icons.person, size: 48, color: Colors.white),
          ),
          const SizedBox(height: 12),
          Text(Session.name ?? 'User',
              textAlign: TextAlign.center,
              style:
                  const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          Text(Session.email ?? '',
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppColors.textMuted)),
          const SizedBox(height: 4),
          Text((Session.role ?? '').toUpperCase(),
              textAlign: TextAlign.center,
              style: const TextStyle(
                  color: AppColors.primary,
                  fontWeight: FontWeight.w600,
                  fontSize: 12)),
          const SizedBox(height: 24),
          _tile(Icons.edit_outlined, 'Edit Profile', () async {
            await Navigator.push(context,
                MaterialPageRoute(builder: (_) => const EditProfileScreen()));
            setState(() {});
          }),
          _tile(Icons.lock_outline, 'Change Password', () {
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const ChangePasswordScreen()));
          }),
          _tile(Icons.account_balance_wallet_outlined, 'Wallet', () {
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const WalletScreen()));
          }),
          _tile(Icons.help_outline, 'Help Center', () {
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const HelpCenterScreen()));
          }),
          _tile(Icons.info_outline, 'About AgriRentX', _about),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.logout, color: AppColors.danger),
              title: const Text('Logout',
                  style: TextStyle(color: AppColors.danger)),
              onTap: _logout,
            ),
          ),
        ],
      ),
    );
  }

  Widget _tile(IconData icon, String label, VoidCallback onTap) => Card(
        margin: const EdgeInsets.only(bottom: 10),
        child: ListTile(
          leading: Icon(icon, color: AppColors.primary),
          title: Text(label),
          trailing: const Icon(Icons.chevron_right),
          onTap: onTap,
        ),
      );
}
