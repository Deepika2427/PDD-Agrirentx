import 'package:flutter/material.dart';
import 'app_theme.dart';
import 'api_service.dart';
import 'equipment_model.dart';
import 'booking_screen.dart';
import 'chat_screen.dart';

class EquipmentDetailsScreen extends StatefulWidget {
  final Equipment equipment;
  const EquipmentDetailsScreen({super.key, required this.equipment});

  @override
  State<EquipmentDetailsScreen> createState() => _EquipmentDetailsScreenState();
}

class _EquipmentDetailsScreenState extends State<EquipmentDetailsScreen> {
  List _reviews = [];
  bool _loadingReviews = true;

  @override
  void initState() {
    super.initState();
    _loadReviews();
  }

  Future<void> _loadReviews() async {
    try {
      _reviews = await ApiService.getReviews(widget.equipment.id);
    } catch (_) {
      _reviews = [];
    } finally {
      if (mounted) setState(() => _loadingReviews = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final e = widget.equipment;
    return Scaffold(
      appBar: AppBar(title: const Text('Equipment Details')),
      body: ListView(
        children: [
          Container(
            height: 200,
            color: AppColors.background,
            child: Center(
              child: Icon(iconForCategory(e.category),
                  size: 90, color: AppColors.primary),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(e.name,
                          style: const TextStyle(
                              fontSize: 22, fontWeight: FontWeight.bold)),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: (e.available
                                ? AppColors.primary
                                : AppColors.danger)
                            .withOpacity(0.12),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(e.available ? 'Available' : 'Rented',
                          style: TextStyle(
                              fontWeight: FontWeight.w600,
                              color: e.available
                                  ? AppColors.primary
                                  : AppColors.danger)),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    const Icon(Icons.star, color: AppColors.warning, size: 18),
                    Text(' ${e.rating}  (${e.reviewCount})  ',
                        style: const TextStyle(fontWeight: FontWeight.w600)),
                    const Icon(Icons.location_on_outlined,
                        size: 16, color: AppColors.textMuted),
                    Expanded(
                      child: Text(e.shortLocation,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: AppColors.textMuted)),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Text('₹${e.pricePerDay.toStringAsFixed(0)} / day',
                    style: const TextStyle(
                        fontSize: 20,
                        color: AppColors.primary,
                        fontWeight: FontWeight.bold)),
                const SizedBox(height: 20),
                _section('Description', e.description),
                _section('Specifications', e.specs),
                const Text('Location',
                    style:
                        TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.location_on, color: AppColors.primary),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(e.location,
                            style:
                                const TextStyle(fontWeight: FontWeight.w600)),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Card(
                  child: ListTile(
                    leading: const CircleAvatar(
                      backgroundColor: AppColors.background,
                      child: Icon(Icons.person, color: AppColors.primary),
                    ),
                    title: Text(e.ownerName.isEmpty ? 'Owner' : e.ownerName),
                    subtitle: const Text('Equipment Owner'),
                    trailing: IconButton(
                      icon: const Icon(Icons.chat_bubble_outline,
                          color: AppColors.primary),
                      onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ChatScreen(
                              otherUserId: e.ownerId,
                              otherUserName:
                                  e.ownerName.isEmpty ? 'Owner' : e.ownerName),
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                const Text('Ratings & Reviews',
                    style:
                        TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                if (_loadingReviews)
                  const Padding(
                    padding: EdgeInsets.all(16),
                    child: Center(child: CircularProgressIndicator()),
                  )
                else if (_reviews.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 8),
                    child: Text('No reviews yet.',
                        style: TextStyle(color: AppColors.textMuted)),
                  )
                else
                  ..._reviews.map((r) => _reviewTile(
                      r['farmer_name'] ?? 'User',
                      (r['rating'] ?? 0).toDouble(),
                      r['comment'] ?? '')),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(16),
        child: ElevatedButton(
          onPressed: e.available
              ? () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => BookingScreen(equipment: e)),
                  )
              : null,
          child: Text(e.available ? 'Book Now' : 'Not Available'),
        ),
      ),
    );
  }

  Widget _section(String title, String body) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style:
                  const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          if (body.isNotEmpty)
            Text(body,
                style:
                    const TextStyle(color: AppColors.textMuted, height: 1.5)),
          const SizedBox(height: 16),
        ],
      );

  Widget _reviewTile(String name, double rating, String text) => Card(
        margin: const EdgeInsets.only(bottom: 10),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(name,
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                  Row(
                    children: [
                      const Icon(Icons.star,
                          size: 15, color: AppColors.warning),
                      Text(' $rating'),
                    ],
                  ),
                ],
              ),
              if (text.isNotEmpty) ...[
                const SizedBox(height: 6),
                Text(text, style: const TextStyle(color: AppColors.textMuted)),
              ],
            ],
          ),
        ),
      );
}
