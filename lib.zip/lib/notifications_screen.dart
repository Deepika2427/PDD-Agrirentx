import 'package:flutter/material.dart';
import 'app_theme.dart';
import 'session.dart';
import 'api_service.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  bool _loading = true;
  List _items = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      _items = await ApiService.notifications(Session.userId!);
    } catch (_) {
      _items = [];
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  IconData _icon(String? name) {
    switch (name) {
      case 'check_circle':
        return Icons.check_circle_outline;
      case 'event_available':
        return Icons.event_available;
      case 'cancel':
        return Icons.cancel_outlined;
      case 'done_all':
        return Icons.done_all;
      default:
        return Icons.notifications_outlined;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Notifications')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _items.isEmpty
              ? const Center(child: Text('No notifications yet'))
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: _items.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (_, i) {
                      final n = _items[i];
                      return Card(
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor: AppColors.background,
                            child: Icon(_icon(n['icon']),
                                color: AppColors.primary),
                          ),
                          title: Text(n['title'] ?? '',
                              style: const TextStyle(
                                  fontWeight: FontWeight.w600)),
                          subtitle: Text(n['body'] ?? ''),
                          trailing: Text(n['created_at'] ?? '',
                              style: const TextStyle(
                                  color: AppColors.textMuted, fontSize: 11)),
                          onTap: () =>
                              ApiService.markNotificationRead(n['id']),
                        ),
                      );
                    },
                  ),
                ),
    );
  }
}
