import 'package:flutter/material.dart';
import 'app_theme.dart';
import 'session.dart';
import 'api_service.dart';
import 'equipment_model.dart';

class AddEquipmentScreen extends StatefulWidget {
  const AddEquipmentScreen({super.key});

  @override
  State<AddEquipmentScreen> createState() => _AddEquipmentScreenState();
}

class _AddEquipmentScreenState extends State<AddEquipmentScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _priceCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  final _specCtrl = TextEditingController();
  final _areaCtrl = TextEditingController();
  final _cityCtrl = TextEditingController();
  final _customCategoryCtrl = TextEditingController();
  String _state = indianStates.first;
  String _category = 'Tractor';
  bool _available = true;
  bool _loading = false;

  String get _effectiveCategory =>
      _category == 'Other' ? _customCategoryCtrl.text.trim() : _category;

  @override
  void initState() {
    super.initState();
    _areaCtrl.text = Session.area ?? '';
    _cityCtrl.text = Session.city ?? '';
    if (Session.state != null && indianStates.contains(Session.state)) {
      _state = Session.state!;
    }
  }

  void _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    try {
      await ApiService.addEquipment({
        'owner_id': Session.userId,
        'name': _nameCtrl.text.trim(),
        'category': _effectiveCategory,
        'area': _areaCtrl.text.trim(),
        'city': _cityCtrl.text.trim(),
        'state': _state,
        'price_per_day': double.tryParse(_priceCtrl.text) ?? 0,
        'description': _descCtrl.text.trim(),
        'specs': _specCtrl.text.trim(),
        'available': _available,
      });
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Equipment added successfully')),
      );
      Navigator.pop(context);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
      );
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final categories = equipmentCategories.where((c) => c != 'All').toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Add Equipment')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 6),
              Center(
                child: Container(
                  height: 90,
                  width: 90,
                  decoration: BoxDecoration(
                    color: AppColors.primary.withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(iconForCategory(_effectiveCategory),
                      size: 44, color: AppColors.primary),
                ),
              ),
              const SizedBox(height: 6),
              const Center(
                child: Text('Icon updates with category',
                    style:
                        TextStyle(color: AppColors.textMuted, fontSize: 12)),
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _nameCtrl,
                decoration: const InputDecoration(labelText: 'Equipment Name'),
                validator: (v) =>
                    v == null || v.isEmpty ? 'Enter a name' : null,
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: _category,
                decoration: const InputDecoration(labelText: 'Category'),
                items: [...categories, 'Other']
                    .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                    .toList(),
                onChanged: (v) => setState(() => _category = v!),
              ),
              if (_category == 'Other') ...[
                const SizedBox(height: 16),
                TextFormField(
                  controller: _customCategoryCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Enter Category',
                    hintText: 'e.g. Seeder, Trailer, Pump',
                  ),
                  onChanged: (_) => setState(() {}),
                  validator: (v) => _category == 'Other' &&
                          (v == null || v.trim().isEmpty)
                      ? 'Enter a category'
                      : null,
                ),
              ],
              const SizedBox(height: 16),
              TextFormField(
                controller: _priceCtrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Rental Price per Day',
                  prefixText: '₹ ',
                ),
                validator: (v) =>
                    v == null || v.isEmpty ? 'Enter a price' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _areaCtrl,
                decoration: const InputDecoration(
                  labelText: 'Area / Village',
                  prefixIcon: Icon(Icons.place_outlined),
                ),
                validator: (v) =>
                    v == null || v.isEmpty ? 'Enter the area' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _cityCtrl,
                decoration: const InputDecoration(
                  labelText: 'City / District',
                  prefixIcon: Icon(Icons.location_city_outlined),
                ),
                validator: (v) =>
                    v == null || v.isEmpty ? 'Enter the city' : null,
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: _state,
                decoration: const InputDecoration(
                  labelText: 'State',
                  prefixIcon: Icon(Icons.map_outlined),
                ),
                items: indianStates
                    .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                    .toList(),
                onChanged: (v) => setState(() => _state = v!),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _specCtrl,
                decoration:
                    const InputDecoration(labelText: 'Specifications'),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _descCtrl,
                maxLines: 3,
                decoration: const InputDecoration(labelText: 'Description'),
              ),
              const SizedBox(height: 8),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                activeColor: AppColors.primary,
                title: const Text('Available for rent'),
                value: _available,
                onChanged: (v) => setState(() => _available = v),
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: _loading ? null : _save,
                child: _loading
                    ? const SizedBox(
                        height: 22,
                        width: 22,
                        child: CircularProgressIndicator(
                            color: Colors.white, strokeWidth: 2.5),
                      )
                    : const Text('Save Equipment'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
