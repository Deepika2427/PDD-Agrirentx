import 'package:flutter/material.dart';
import 'app_theme.dart';

class HelpCenterScreen extends StatelessWidget {
  const HelpCenterScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final faqs = [
      {
        'q': 'How do I book equipment?',
        'a': 'Browse or search equipment, open its details, tap Book Now, choose your rental dates and confirm.'
      },
      {
        'q': 'How is the rental cost calculated?',
        'a': 'The cost is the price per day multiplied by the number of days you select.'
      },
      {
        'q': 'Can I cancel a booking?',
        'a': 'Yes, you can cancel a booking before the owner approves it from the My Bookings screen.'
      },
      {
        'q': 'How do refunds work?',
        'a': 'Approved refunds are credited back to your wallet within a few working days.'
      },
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Help Center')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Frequently Asked Questions',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          ...faqs.map((f) => Card(
                margin: const EdgeInsets.only(bottom: 10),
                child: ExpansionTile(
                  shape: const Border(),
                  iconColor: AppColors.primary,
                  title: Text(f['q']!,
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                  childrenPadding:
                      const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  children: [
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Text(f['a']!,
                          style:
                              const TextStyle(color: AppColors.textMuted)),
                    ),
                  ],
                ),
              )),
          const SizedBox(height: 20),
          const Text('Need more help?',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.email_outlined,
                  color: AppColors.primary),
              title: const Text('Contact Support'),
              subtitle: const Text('support@agrirentx.com'),
              onTap: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Opening support...')),
                );
              },
            ),
          ),
          Card(
            child: ListTile(
              leading: const Icon(Icons.report_outlined,
                  color: AppColors.primary),
              title: const Text('Raise a Complaint'),
              onTap: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Complaint form coming soon')),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
